/*
 * Lippman text
 * Exercise 1.03:  Write a program to print 'Hello, World' on the standard output.
 */

// Samuel Bishop
// Professor Fischer
// ECE 3220: Software Dev in C/C++
// August 24, 2019

/* GENERAL INCLUDES */
#include <stdio.h>
#include <iostream>

/* CONSTANT DECLARATIONS */

/* FUNCTION DECLARATIONS */

/* MAIN */
int main()
{
	std::cout << "Hello, World" << std::endl;
	return 0;
}
