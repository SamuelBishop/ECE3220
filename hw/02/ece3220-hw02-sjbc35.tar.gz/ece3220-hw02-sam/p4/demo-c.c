/* demo-c.c */

extern void foo();

int main()
{
	foo();  // defined in the C++ source file demo-cc.cc
	return 0;
}
