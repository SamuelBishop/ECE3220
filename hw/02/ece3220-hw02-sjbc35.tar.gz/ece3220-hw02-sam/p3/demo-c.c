/* demo-c.c */

#include <stdio.h>

void foo()
{
	printf("Hello, World!\n");
}
