float foo(double d) { return 5.0F; }
