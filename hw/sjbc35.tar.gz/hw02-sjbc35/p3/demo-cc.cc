/* demo-cc.cc */

// function declaration
void foo();

int main()
{
	foo();  // defined in the C source file demo-c.c
	return 0;
}
