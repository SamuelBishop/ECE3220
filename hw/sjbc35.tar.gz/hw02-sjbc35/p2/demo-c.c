void foo() { }
int foo(const char *p) { return 0; }
const char * foo(int I) { return 0; }
float foo(double d) { return 5.0F; }
