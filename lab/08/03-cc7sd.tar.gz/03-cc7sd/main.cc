#include "rpi3b_accessory.h"

using namespace ece3220;
using namespace std;

int main()
{
    int exit_code = 0;

    rpi3b_accessory  &a = rpi3b_accessory::getInstance();

    /* your code here ... */

    return exit_code;
}
