/*
 *  File name : hello-world-cpp.cpp
 */
#include <iostream>
#include <cstdlib>

int main()
{
    std::cout << "Hello, World!!! (C++ program)" << std::endl;
    return EXIT_SUCCESS;
}
