/*
 *  File name : hello-world-c.c
 */
#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello, World!!! (C program)\n");
    return EXIT_SUCCESS;
}
