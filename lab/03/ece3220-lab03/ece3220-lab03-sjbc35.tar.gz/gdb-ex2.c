#include <stdio.h>
void main()
{
    char p[7] = "Mizzou";
    p[ 3 ] = 'P';
    printf("%s", p);
}
