#include "rpi3b_accessory.h"

namespace ece3220 {

/** \brief Default constructor
 */
rpi3b_accessory :: rpi3b_accessory ()
{
    // wiringPi library setup() call
    /* Your code here ... */

    /* LEDs */

    // Configure the GPIO pins that are connected to the four LEDs on the
    // accessory board, and then turn OFF the LEDs.
    /* Your code here ... */
}


/** \brief Destructor
 */
rpi3b_accessory :: ~rpi3b_accessory()
{
    /*
     * Configure all GPIO pins as INPUTs
     */
    /* Your code here ... */
}


/** \brief Gets a reference to the singleton instance of the rpi3b_accessory class.
 *  
 *  The singleton instance of the rpi3b_accessory class is constructed the
 *  first time this method is called. See also [1] in `readme.txt'.
 * 
 *  \return Reference to the static sintleton instance.
 */
rpi3b_accessory &
rpi3b_accessory :: getInstance()
{
#if 1
    static rpi3b_accessory  instance;
    return instance;
#else
    // If an object of class `rpi3b_accessory' occupies a large amount of
    // storage, that storage should be allocated dynamically from the
    // system heap at runtime via C++'s `new' operator. The address
    // returned by the new operator should be stored within a C++
    // `unique_ptr<>' smart pointer object having static storage duration
    // within the getInstance() method.
    static std::unique_ptr< rpi3b_accessory >  instance( new rpi3b_accessory );
    return  *instance ;
#endif
}


/** \brief Turns ON|OFF all LEDs on the accessory board. 
 *
 * \param state HIGH or 1 turns all LEDs ON. LOW or 0 turns all LEDs OFF.
 */
void
rpi3b_accessory :: ledWriteAll ( int state )
{
    // Write the value `state' to all four LEDs
    /* Your code here ... */
}

} // namespace ece3220

